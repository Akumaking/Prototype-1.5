# FA-Scan

Design a registration form, print it, scan the shaded copies, and see the results as charts.

FA-Scan opens with the DICT Cordillera logo on white: 5 seconds fade in, 5 seconds fade out, then the system (click or press any key to skip). The logo file is `frontend/public/dict-logo.png`.

## Install on a computer (recommended; works with Windows Smart App Control)

1. Give the other person `dist\FA-Scan-setup.zip` (about 1 MB; build it with `make_package.bat`).
2. They unzip it and double-click **Setup.bat**. It installs Python 3.12 if needed, creates FA-Scan's private Python environment, installs the packages, puts an **FA-Scan icon on the desktop**, and starts the app. Running it again is safe. It needs internet the first time: about 75 MB of packages, plus a 26 MB Python installer on a computer that has no Python. Each download shows a progress bar with `MB downloaded / MB total`, the speed and the time left (`Setup-download.ps1` does this; the Python installer comes from python.org and is only run if it is signed by the Python Software Foundation). If the bar cannot be used, Setup falls back to pip's and winget's own progress.
3. From then on they open FA-Scan from the desktop icon (or `FA-Scan.bat`). It opens in its own app-style window (Microsoft Edge, or Chrome, without tabs or an address bar), and shuts down about 10 seconds after the window is closed.

This route only runs Windows' own signed Python and well-known packages, so Smart App Control accepts it. The packaged `.exe` below is **not** accepted by Smart App Control (it blocks unsigned apps it has never seen), so don't give that to people whose PC has Smart App Control on.

## Packaged .exe (blocked by Smart App Control unless signed)

Run `build_desktop.bat` once (needs Python 3.12). It produces `dist\FA-Scan\FA-Scan.exe`; copy the whole `dist\FA-Scan` folder to any Windows laptop and double-click `FA-Scan.exe`. Nothing else needs installing: the app opens in its own window using Microsoft Edge (included with Windows 10/11) in app mode, or Chrome if Edge is missing, or your default browser as a last resort. It deliberately uses no extra .NET/WebView helper files, because Windows' Smart App Control blocks those in unsigned apps.

**Windows security warnings:** the app is not code-signed, so Windows may show "Windows protected your PC" (More info → Run anyway). On a PC with *Smart App Control* switched on, Windows can refuse unsigned apps entirely; the lasting fix is to sign the app with a code-signing certificate.

- Closing the window stops the program. Only one copy can run at a time.
- Its data (records, scans, inbox, logs) lives in `%LOCALAPPDATA%\FA-Scan\data`. The inbox folder is `%LOCALAPPDATA%\FA-Scan\data\inbox`.
- The browser version below keeps working as a fallback. If both are open, only one of them watches the inbox folder.

## Run it (browser version)

**Easiest:** double-click `FA-Scan.bat`. It starts the server, opens the site in your browser, and shuts the server down about 10 seconds after the last FA-Scan tab is closed (log: `backend/data/server.log`). Right-click it → Send to → Desktop (create shortcut) for a desktop icon.

Manual start (stays running until you press Ctrl+C):

```bash
# one time
cd backend && python -m venv .venv && .venv\Scripts\pip install -r requirements.txt
cd ../frontend && npm install && npm run build

# every time
cd backend && .venv\Scripts\python -m uvicorn app.main:app --port 8000
```

Open http://127.0.0.1:8000. There is no sign-in: the app only listens on this computer, and every request must carry a header that other websites cannot send, so a web page open in your browser cannot read or change the records.

For frontend development run `npm run dev` in `frontend/` (port 5173, proxies `/api` to 8000).

## How it works

1. **Forms** → build a form (columns, options, "choose one / many", which chart a column feeds). Choose the **orientation** (portrait / landscape) and **paper size** (A4, Letter or Long 8.5 x 13 in; long paper is taller than the glass of most printers' scanners, so it needs a feeder or a large glass to scan), and whether the page is for **one person** or **many people** (a table with one row per person; `Fill the page with rows` or a number of rows). Start from a **template** (Registration form; Attendance sheet with a written Name and Time arrived; or DTC Digital Login, which copies the DTC Baguio Google Form's questions so its answers import without changes) and add **write-in boxes** for anything people write by hand. FA-Scan does not read handwriting: it keeps the scan so you can read it in **Data → Review**, where you can optionally type it in so it appears in the exports. A row with only handwriting is still kept; a row with nothing in it is ignored. Preview, then Print or save the PDF at 100% scale.
2. Shade circles on the printed copy, scan it (image or PDF).
3. **Start Scanning** → upload scans, or have the scanner save to `backend/data/inbox` (read every few seconds with the *active* form; results move to `inbox/done` or `inbox/failed`).
   **Scanning from the printer:** with the printer on and connected by USB, open Start Scanner. Your scanner is listed under "Scan Devices"; put the printed form face down on the glass and press **Scan page** (or Enter). The page is scanned at 200 DPI, read, and saved, and the answers appear in the window. Press again for the next page. This uses Windows' built-in scanner system (WIA), so the printer's scanner must show up in Windows (Settings → Printers & scanners). A scanner with a feeder can scan a stack with the "Document feeder" box ticked. If the scanner isn't listed, press Refresh, or use the inbox folder / upload instead.

   *Development without a scanner:* set `FASCAN_FAKE_SCANNER` to a folder of page images and a "Test scanner" appears that hands them out one by one.
4. The OMR step (`backend/app/omr.py`) finds the 4 corner marks, straightens the page (upside-down and skewed scans work), and measures how dark each circle is.
5. On a many-people sheet every filled row becomes its own record (rows nobody filled in are ignored). Blank or double-shaded answers are flagged and shown in **Data → Review** next to the scan image (for a sheet: just that person's row under the column headings).
6. The dashboard reads the stored records. Each record keeps the date and time it was scanned.
7. **Export** → FA-Scan keeps `FA-Scan registrations.xlsx` and `.csv` up to date in a folder you choose (default `Documents\FA-Scan Exports`) after every scan, edit or delete. Putting that folder inside Google Drive for desktop or OneDrive also syncs the files to the cloud. The records themselves live in a local database file.
8. **Google Form answers** → on **Data**, press *Import from Google Form*. In Google Forms open Responses → Link to Sheets, then in the sheet choose File → Download → CSV (or Excel) and pick that file. FA-Scan matches the file's columns to the form's questions by name (you can change any match), shows how many registrations will be added and which answers don't match an option, then adds them next to the scanned ones, tagged *Google Form* (and shown in the export's *Source* column). Answers that are blank or not one of the options are marked **Needs review**. Importing the same file again skips people already imported. Only the download needs internet; the import itself works on the file on this computer. The Google Form's date and time are kept as the registration time. **Live link:** instead of downloading each time, press *Live link* on Data and paste the link of the Google Sheet (File → Share → Publish to web → CSV, or a sheet shared as "Anyone with the link can view"). FA-Scan checks it every 2, 5, 15 or 30 minutes while it is open and adds new answers by itself (same matching, same duplicate skipping). It needs the internet only for each check; if Google can't be reached the status on Data says so and nothing is lost. Only Google addresses are ever opened. Anyone with the published link can read the whole sheet, so share it carefully and use "Stop publishing" in Google when done. The link is stored in the local database. **Dashboard:** every choose-one / choose-many question gets its own bar chart (how many people picked each answer, and the share of people who answered), next to the Gender and Category charts.

## Layout

- `backend/app/formgen.py` – form layout and rendering (same layout drives printing and reading)
- `backend/app/omr.py` – scan alignment and bubble detection
- `backend/app/main.py` – API, local-only protection, inbox watcher
- `backend/app/scanner.py` – scanning through the printer's scanner (Windows WIA)
- `backend/app/exporter.py` – Excel / CSV export
- `backend/app/importer.py` – reads a Google Form's answers (downloaded CSV / Excel, or a published Google Sheet link) and matches them to a form
- `backend/tools/make_samples.py` – fake filled scans for testing without a scanner
- `backend/tests` – `python -m pytest tests`
- `frontend/src` – React UI

## Not done yet

- Handwriting (OCR). Only shaded circles are read; names and times written in boxes are kept as part of the scan, not turned into text (you can type them in during review).
- The real scan from a printer's glass has only been tried with a pretend scanner so far.
- Editing a form after copies were printed moves the circles; create a new form instead.



