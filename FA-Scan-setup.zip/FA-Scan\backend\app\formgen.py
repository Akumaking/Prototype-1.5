"""Form layout + rendering.

The layout is computed purely from the form schema, so the same function tells the renderer where to
draw circles and tells the OMR reader where to look. Coordinates are pixels at 200 DPI.

Schema (stored per form):
  fields: [{id, label, type: single|multi, role, options}]
  page:   {size: "A4"|"Letter", orientation: "portrait"|"landscape"}      (default A4 portrait)
  layout: {mode: "single"|"rows", rows: int|None}                        (default one person per page)
In "rows" mode the page is a table: one row per person, every option of every field is a column.
"""
import io
import math

from PIL import Image, ImageDraw, ImageFont

PAGE_SIZES = {"A4": (1654, 2339), "Letter": (1700, 2200), "Long": (1700, 2600)}   # portrait (width, height); Long = 8.5 x 13 in
MARK_INSET = 65
MARK_SIZES = [70, 50, 50, 50]   # top-left is larger so scan orientation can be detected
X0 = 130
ROW_H = 65
R = 20
MIN_COL_W = 62                  # narrowest option column in a multi-row sheet
WRITE_SHARES = {"wide": 4, "narrow": 2}  # a written-in column is this many option-column widths wide
MAX_UNIT = 330                            # an option column never gets wider than this; a tiny table is centred instead
WRITE_BOX_H = 80                          # height of a written-in box on a one-person page
W, H = PAGE_SIZES["A4"]          # defaults (A4 portrait), kept for callers that don't care about page size


def page_dims(schema: dict) -> tuple[int, int]:
    p = schema.get("page") or {}
    w, h = PAGE_SIZES.get(p.get("size", "A4"), PAGE_SIZES["A4"])
    return (h, w) if p.get("orientation") == "landscape" else (w, h)


def mark_centers(w: int, h: int) -> list[tuple[int, int]]:
    """TL, TR, BR, BL."""
    return [(MARK_INSET, MARK_INSET), (w - MARK_INSET, MARK_INSET), (w - MARK_INSET, h - MARK_INSET), (MARK_INSET, h - MARK_INSET)]


MARK_CENTERS = mark_centers(W, H)


def compute_layout(schema: dict) -> dict:
    w, h = page_dims(schema)
    mode = (schema.get("layout") or {}).get("mode", "single")
    return _rows_layout(schema, w, h) if mode == "rows" else _single_layout(schema, w, h)


def _single_layout(schema: dict, w: int, h: int) -> dict:
    cols = max(2, min(5, (w - 2 * X0) // 460))
    colw = (w - 2 * X0) // cols
    y = 300
    fields = []
    for f in schema["fields"]:
        label_y = y
        y += 55
        if f.get("type") == "write":   # a blank box to write in; the app does not read handwriting
            bw = (w - 2 * X0) if f.get("size", "wide") == "wide" else (w - 2 * X0) // 3
            fields.append({"id": f["id"], "label": f["label"], "type": "write", "role": None, "label_y": label_y,
                           "options": [], "box": [X0, y, X0 + bw, y + WRITE_BOX_H]})
            y += WRITE_BOX_H + 40
            continue
        opts = []
        for i, label in enumerate(f["options"]):
            row, col = divmod(i, cols)
            opts.append({"label": label, "cx": X0 + col * colw + R, "cy": y + row * ROW_H + R, "r": R})
        rows = max(1, math.ceil(len(opts) / cols))
        y += rows * ROW_H + 40
        fields.append({"id": f["id"], "label": f["label"], "type": f.get("type", "single"),
                       "role": f.get("role"), "label_y": label_y, "options": opts})
    if y > h - 160:
        raise ValueError("Form is too long to fit on one page. Remove a column or option, or use landscape.")
    return {"mode": "single", "width": w, "height": h, "marks": mark_centers(w, h), "colw": colw, "fields": fields,
            "rows": None, "max_rows": None}


def _rows_layout(schema: dict, w: int, h: int) -> dict:
    """A table spread evenly across the page: the same margin on the left and the right. Every option column
    gets one share of the width and written boxes get proportionally more (wide = 4 shares, narrow = 2), so a
    landscape page is filled instead of leaving empty space at the side. If there are few columns the shares
    stop growing at a comfortable size and the table is centred."""
    fields = schema["fields"]
    n_opts = sum(len(f["options"]) for f in fields if f.get("type") != "write")
    shares = n_opts + sum(WRITE_SHARES.get(f.get("size", "wide"), 4) for f in fields if f.get("type") == "write")
    num_w = 90
    usable = w - 2 * X0 - num_w
    unit = usable / shares
    if n_opts and unit < MIN_COL_W:
        raise ValueError("Too many columns for a multi-row sheet. Use landscape, make the written boxes narrower, or remove some options.")
    unit = min(unit, MAX_UNIT)
    col_w = unit
    left = (w - (num_w + shares * unit)) / 2        # equal margin on both sides
    r = int(min(18, col_w / 2 - 8))
    y0, row_h, footer = 440, 66, h - 170
    max_rows = int((footer - y0) // row_h)
    want = (schema.get("layout") or {}).get("rows")
    rows = max_rows if not want else int(want)
    if rows < 1 or rows > max_rows:
        raise ValueError(f"Only {max_rows} rows fit on this page. Use fewer rows, or switch the page orientation.")
    x = float(left + num_w)
    header = []
    for f in fields:
        if f.get("type") == "write":
            wd = WRITE_SHARES.get(f.get("size", "wide"), 4) * unit
            header.append({"id": f["id"], "label": f["label"], "type": "write", "role": None, "size": f.get("size", "wide"),
                           "x0": int(round(x)), "x1": int(round(x + wd)), "options": []})
            x += wd
            continue
        opts = [{"label": label, "cx": int(round(x + (j + 0.5) * col_w))} for j, label in enumerate(f["options"])]
        header.append({"id": f["id"], "label": f["label"], "type": f.get("type", "single"), "role": f.get("role"),
                       "x0": int(round(x)), "x1": int(round(x + len(opts) * col_w)), "options": opts})
        x += len(opts) * col_w
    rows_data = []
    for i in range(rows):
        cy = int(y0 + i * row_h + row_h / 2)
        rfields = []
        for hf in header:
            item = {"id": hf["id"], "label": hf["label"], "type": hf["type"], "role": hf["role"],
                    "options": [{"label": o["label"], "cx": o["cx"], "cy": cy, "r": r} for o in hf["options"]]}
            if hf["type"] == "write":
                item["box"] = [hf["x0"], cy - row_h // 2, hf["x1"], cy + row_h // 2]
            rfields.append(item)
        rows_data.append({"row": i + 1, "cy": cy, "fields": rfields})
    return {"mode": "rows", "width": w, "height": h, "marks": mark_centers(w, h), "rows": rows, "max_rows": max_rows,
            "row_h": row_h, "y0": y0, "col_w": col_w, "num_w": num_w, "r": r, "fields": header, "rows_data": rows_data,
            "left": int(round(left)), "x_end": header[-1]["x1"]}


def layout_info(schema: dict) -> dict:
    """What the UI needs to describe a form's page."""
    p = schema.get("page") or {}
    lay = compute_layout(schema)
    return {"size": p.get("size", "A4"), "orientation": p.get("orientation", "portrait"), "mode": lay["mode"],
            "rows": lay["rows"], "max_rows": lay["max_rows"], "width": lay["width"], "height": lay["height"]}


def _font(size: int, bold: bool = False):
    names = ["arialbd.ttf", "arial.ttf"] if bold else ["arial.ttf"]
    names += ["DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"]
    for n in names:
        try:
            return ImageFont.truetype(n, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def _wrap(d: ImageDraw.ImageDraw, text: str, font, max_w: float, max_lines: int = 2) -> list[str]:
    lines, cur = [], ""
    for word in text.split():
        trial = (cur + " " + word).strip()
        if d.textlength(trial, font=font) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    lines.append(cur)
    return lines[:max_lines] if len(lines) <= max_lines else lines[:max_lines - 1] + [" ".join(lines[max_lines - 1:])]


def _title_block(d, layout, title):
    w = layout["width"]
    d.text((w // 2, 150), title, font=_font(56, True), fill="black", anchor="mm")
    note = "Please shade the circle that applies using a dark pen or pencil."
    if any(f["type"] == "write" for f in layout["fields"]):
        note += " Write clearly in the boxes provided."
    d.text((w // 2, 215), note, font=_font(28), fill="#444", anchor="mm")
    d.line([(X0, 260), (w - X0, 260)], fill="#999", width=2)


def render_form(schema: dict, title: str, form_id: int | None = None) -> Image.Image:
    layout = compute_layout(schema)
    w, h = layout["width"], layout["height"]
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    for (cx, cy), s in zip(layout["marks"], MARK_SIZES):
        d.rectangle([cx - s // 2, cy - s // 2, cx + s // 2, cy + s // 2], fill="black")
    _title_block(d, layout, title)
    if layout["mode"] == "rows":
        _draw_rows(d, layout)
        footer = f"FA-SCAN form #{form_id}" if form_id else "FA-SCAN form"
        footer += f"  ·  {layout['rows']} rows, one person per row"
    else:
        _draw_single(d, layout)
        footer = f"FA-SCAN form #{form_id}" if form_id else "FA-SCAN form"
    d.text((w // 2, h - 110), footer, font=_font(22), fill="#888", anchor="mm")
    return img


def _draw_single(d, layout):
    lf, of = _font(34, True), _font(30)
    for f in layout["fields"]:
        suffix = {"single": "  (choose one)", "multi": "  (choose all that apply)", "write": "  (write here)"}[f["type"]]
        d.text((X0, f["label_y"]), f["label"], font=lf, fill="black")
        lw = d.textlength(f["label"], font=lf)
        d.text((X0 + lw, f["label_y"] + 6), suffix, font=_font(24), fill="#777")
        if f["type"] == "write":
            d.rectangle(f["box"], outline="#444", width=3)
            continue
        for o in f["options"]:
            d.ellipse([o["cx"] - o["r"], o["cy"] - o["r"], o["cx"] + o["r"], o["cy"] + o["r"]], outline="black", width=3)
            d.text((o["cx"] + o["r"] + 15, o["cy"]), o["label"], font=of, fill="black", anchor="lm")


def _draw_rows(d, layout):
    col_w, y0, row_h, rows = layout["col_w"], layout["y0"], layout["row_h"], layout["rows"]
    bottom = y0 + rows * row_h
    left, right = layout["left"], layout["x_end"]
    # table frame and field separators
    d.line([(left, 290), (left, bottom)], fill="#555", width=2)
    d.line([(right, 290), (right, bottom)], fill="#555", width=2)
    d.line([(left, y0), (right, y0)], fill="#555", width=2)
    d.line([(left, bottom), (right, bottom)], fill="#555", width=2)
    d.text((left + layout["num_w"] // 2, y0 - 38), "No.", font=_font(22, True), fill="black", anchor="mm")
    d.line([(left + layout["num_w"], 290), (left + layout["num_w"], bottom)], fill="#aaa", width=1)
    lab_font = _font(22, True)
    for fi, f in enumerate(layout["fields"]):
        if fi:
            d.line([(f["x0"], 290), (f["x0"], bottom)], fill="#555", width=2)
        mid = (f["x0"] + f["x1"]) / 2
        text = f["label"] + (" (all that apply)" if f["type"] == "multi" else "")
        d.text((mid, 308), text, font=_font(26, True), fill="black", anchor="mm")
        d.line([(f["x0"] + 8, 330), (f["x1"] - 8, 330)], fill="#999", width=2)
        for o in f["options"]:
            font = _font(20)
            lines = _wrap(d, o["label"], font, col_w - 6)
            if any(d.textlength(t, font=font) > col_w - 6 for t in lines):
                font = _font(16)
            for li, t in enumerate(lines):
                d.text((o["cx"], 352 + li * 24), t, font=font, fill="black", anchor="mm")
    num_font = _font(24)
    for rd in layout["rows_data"]:
        cy = rd["cy"]
        if rd["row"] < rows:
            d.line([(left, cy + row_h // 2), (right, cy + row_h // 2)], fill="#ccc", width=1)
        d.text((left + layout["num_w"] // 2, cy), str(rd["row"]), font=num_font, fill="#333", anchor="mm")
        for f in rd["fields"]:
            for o in f["options"]:
                d.ellipse([o["cx"] - o["r"], o["cy"] - o["r"], o["cx"] + o["r"], o["cy"] + o["r"]], outline="black", width=3)


def render_png(schema, title, form_id=None) -> bytes:
    buf = io.BytesIO()
    render_form(schema, title, form_id).save(buf, "PNG")
    return buf.getvalue()


def render_pdf(schema, title, form_id=None) -> bytes:
    img = render_form(schema, title, form_id)
    buf = io.BytesIO()
    img.save(buf, "PDF", resolution=200)
    return buf.getvalue()
