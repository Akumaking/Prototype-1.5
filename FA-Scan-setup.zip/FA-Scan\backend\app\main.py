import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import cv2
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db, exporter, formgen, omr, scanner

app = FastAPI(title="FA-Scan")


@app.on_event("startup")
def _startup():
    db.init_db()
    (db.DATA_DIR / "scans").mkdir(parents=True, exist_ok=True)
    (db.DATA_DIR / "inbox").mkdir(parents=True, exist_ok=True)
    threading.Thread(target=_watch_inbox, daemon=True).start()
    if AUTOCLOSE:
        threading.Thread(target=_autoclose_loop, daemon=True).start()


# ---------- auto-close (only when started by launcher.py) ----------
# Open browser tabs ping every few seconds and say goodbye when they close. When no tab is left
# for a short grace period (long enough for a page reload), the server exits.
AUTOCLOSE = os.environ.get("FASCAN_AUTOCLOSE") == "1"
_tabs: dict[str, float] = {}
_tabs_lock = threading.Lock()
_ever_seen = False
GRACE_AFTER_CLOSE = 10      # seconds with no tab before exiting
GRACE_NEVER_OPENED = 90     # seconds to wait for the very first tab
TAB_STALE = 300             # a tab that stops pinging (crash, sleeping laptop) is dropped after this


async def _tab_id(request: Request) -> str:
    return (await request.body()).decode("utf-8", "ignore").strip()[:64] or "anon"


@app.post("/api/ping")
async def ping(request: Request):
    global _ever_seen
    tid = await _tab_id(request)
    with _tabs_lock:
        _tabs[tid] = time.time()
        _ever_seen = True
    return {"ok": True, "autoclose": AUTOCLOSE}


@app.post("/api/bye")
async def bye(request: Request):
    tid = await _tab_id(request)
    with _tabs_lock:
        _tabs.pop(tid, None)
    return {"ok": True}


def _autoclose_loop():
    empty_since = time.time()
    while True:
        time.sleep(1)
        now = time.time()
        with _tabs_lock:
            for t in [t for t, seen in _tabs.items() if now - seen > TAB_STALE]:
                del _tabs[t]
            has_tabs, seen_any = bool(_tabs), _ever_seen
        if has_tabs:
            empty_since = None
        else:
            empty_since = empty_since or now
            if now - empty_since > (GRACE_AFTER_CLOSE if seen_any else GRACE_NEVER_OPENED):
                os._exit(0)


# ---------- local-only protection ----------
# There is no sign-in: the app only listens on this computer. To stop a web page the person happens to have
# open in their browser from quietly calling it, every /api request must come to localhost and carry a
# custom header that other sites' scripts cannot send without our permission.
LOCAL_USER = "0001"
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "[::1]", "testserver"}
_OPEN_PATHS = {"/api/ping", "/api/bye"}   # sent by the browser as it closes; carry no data


@app.middleware("http")
async def local_only(request: Request, call_next):
    p = request.url.path
    if p.startswith("/api/") and p not in _OPEN_PATHS:
        host = request.headers.get("host", "").rsplit(":", 1)[0].lower() if not request.headers.get("host", "").startswith("[") else "[::1]"
        if host not in _LOCAL_HOSTS or request.headers.get("x-fascan") != "1":
            return JSONResponse({"detail": "Forbidden"}, status_code=403)
    return await call_next(request)


def current_user() -> str:
    return LOCAL_USER


# ---------- forms ----------
class FieldIn(BaseModel):
    id: str
    label: str
    type: str = "single"
    role: str | None = None
    options: list[str] = []
    size: str | None = None               # write-in boxes only: wide (names) | narrow (times)


class FormIn(BaseModel):
    name: str
    title: str | None = None
    fields: list[FieldIn]
    page_size: str = "A4"                 # A4 | Letter
    orientation: str = "portrait"         # portrait | landscape
    layout: str = "single"                # single (one person per page) | rows (many people per page)
    rows: int | None = None               # rows mode: how many rows; None = fill the page


def _clean_schema(body: FormIn) -> dict:
    if not body.fields:
        raise HTTPException(400, "Add at least one column")
    fields, seen = [], set()
    for i, f in enumerate(body.fields):
        fid = re.sub(r"[^a-z0-9_]", "", f.id.lower()) or f"field{i + 1}"
        if fid in seen:
            fid = f"{fid}_{i}"
        seen.add(fid)
        if f.type not in ("single", "multi", "write"):
            raise HTTPException(400, "type must be single, multi or write")
        if f.type == "write":          # a box to write in: no options, not used in charts
            if f.size not in (None, "wide", "narrow"):
                raise HTTPException(400, "box size must be wide or narrow")
            fields.append({"id": fid, "label": f.label.strip() or fid, "type": "write", "role": None, "options": [],
                           "size": f.size or "wide"})
            continue
        opts = [o.strip() for o in f.options if o.strip()]
        if len(opts) < 2:
            raise HTTPException(400, f"'{f.label}' needs at least 2 options")
        if f.role not in (None, "", "gender", "type", "time"):
            raise HTTPException(400, "unknown role")
        fields.append({"id": fid, "label": f.label.strip() or fid, "type": f.type, "role": f.role or None, "options": opts})
    if body.page_size not in formgen.PAGE_SIZES:
        raise HTTPException(400, "Paper size must be A4, Letter or Long")
    if body.orientation not in ("portrait", "landscape"):
        raise HTTPException(400, "Orientation must be portrait or landscape")
    if body.layout not in ("single", "rows"):
        raise HTTPException(400, "Layout must be single or rows")
    schema = {"fields": fields, "page": {"size": body.page_size, "orientation": body.orientation},
              "layout": {"mode": body.layout, "rows": body.rows if body.layout == "rows" and body.rows else None}}
    try:
        formgen.compute_layout(schema)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return schema


def _form_row(r):
    schema = json.loads(r["schema"])
    try:
        info = formgen.layout_info(schema)
    except ValueError:
        info = None
    return {"id": r["id"], "name": r["name"], "title": r["title"], "active": bool(r["active"]),
            "created_at": r["created_at"], "fields": schema["fields"],
            "page": schema.get("page") or {"size": "A4", "orientation": "portrait"},
            "layout": schema.get("layout") or {"mode": "single", "rows": None}, "info": info}


# Previews of a form that is still being edited: nothing is saved.
@app.post("/api/forms/draft-info", dependencies=[Depends(current_user)])
def draft_info(body: FormIn):
    schema = _clean_schema(body)
    return {"info": formgen.layout_info(schema), "page": schema["page"], "layout": schema["layout"]}


@app.post("/api/forms/draft.png", dependencies=[Depends(current_user)])
def draft_png(body: FormIn):
    return Response(formgen.render_png(_clean_schema(body), body.title or body.name), media_type="image/png")


@app.post("/api/forms/draft.pdf", dependencies=[Depends(current_user)])
def draft_pdf(body: FormIn):
    return Response(formgen.render_pdf(_clean_schema(body), body.title or body.name), media_type="application/pdf")


@app.get("/api/forms", dependencies=[Depends(current_user)])
def list_forms():
    con = db.connect()
    rows = con.execute("SELECT * FROM forms ORDER BY id DESC").fetchall()
    con.close()
    return [_form_row(r) for r in rows]


@app.post("/api/forms", dependencies=[Depends(current_user)])
def create_form(body: FormIn, user: str = Depends(current_user)):
    schema = _clean_schema(body)
    con = db.connect()
    cur = con.execute("INSERT INTO forms (name,title,schema) VALUES (?,?,?)",
                      (body.name, body.title or body.name, json.dumps(schema)))
    con.commit()
    row = con.execute("SELECT * FROM forms WHERE id=?", (cur.lastrowid,)).fetchone()
    con.close()
    db.log(user, "form_create", f"Created form “{body.name}” ({len(schema['fields'])} columns)")
    return _form_row(row)


@app.put("/api/forms/{form_id}", dependencies=[Depends(current_user)])
def update_form(form_id: int, body: FormIn, user: str = Depends(current_user)):
    schema = _clean_schema(body)
    con = db.connect()
    con.execute("UPDATE forms SET name=?, title=?, schema=? WHERE id=?",
                (body.name, body.title or body.name, json.dumps(schema), form_id))
    con.commit()
    row = con.execute("SELECT * FROM forms WHERE id=?", (form_id,)).fetchone()
    con.close()
    if not row:
        raise HTTPException(404)
    db.log(user, "form_update", f"Edited form “{body.name}”")
    return _form_row(row)


@app.post("/api/forms/{form_id}/activate", dependencies=[Depends(current_user)])
def activate_form(form_id: int, user: str = Depends(current_user)):
    name = _get_form(form_id)["name"]
    con = db.connect()
    con.execute("UPDATE forms SET active=0")
    con.execute("UPDATE forms SET active=1 WHERE id=?", (form_id,))
    con.commit()
    con.close()
    db.log(user, "form_activate", f"“{name}” is now the active form for scanning")
    return {"ok": True}


@app.delete("/api/forms/{form_id}", dependencies=[Depends(current_user)])
def delete_form(form_id: int, user: str = Depends(current_user)):
    name = _get_form(form_id)["name"]
    con = db.connect()
    if con.execute("SELECT COUNT(*) FROM records WHERE form_id=?", (form_id,)).fetchone()[0]:
        con.close()
        raise HTTPException(400, "This form has scanned records and can't be deleted")
    con.execute("DELETE FROM forms WHERE id=?", (form_id,))
    con.commit()
    con.close()
    db.log(user, "form_delete", f"Deleted form “{name}”", "warn")
    return {"ok": True}


def _get_form(form_id: int):
    con = db.connect()
    row = con.execute("SELECT * FROM forms WHERE id=?", (form_id,)).fetchone()
    con.close()
    if not row:
        raise HTTPException(404, "Form not found")
    return row


@app.get("/api/forms/{form_id}/preview.png", dependencies=[Depends(current_user)])
def form_png(form_id: int):
    r = _get_form(form_id)
    return Response(formgen.render_png(json.loads(r["schema"]), r["title"], r["id"]), media_type="image/png")


@app.get("/api/forms/{form_id}/form.pdf", dependencies=[Depends(current_user)])
def form_pdf(form_id: int):
    r = _get_form(form_id)
    return Response(formgen.render_pdf(json.loads(r["schema"]), r["title"], r["id"]), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="form-{form_id}.pdf"'})


# ---------- scanning ----------
def _derive(schema: dict, answers: dict):
    """Pick the gender / category / time-in answers out of a record by the roles set in the form builder."""
    gender = type_ = time_in = None
    for f in schema["fields"]:
        sel = answers.get(f["id"], {}).get("selected", [])
        if not sel:
            continue
        if f.get("role") == "gender":
            gender = sel[0]
        elif f.get("role") == "type":
            type_ = sel[0]
        elif f.get("role") == "time":
            time_in = sel[0]
    return gender, type_, time_in


def process_image(form_row, img, label: str) -> dict:
    """Read one scanned page and save a record for each person on it (one for a normal form, one per
    filled row for a multi-row sheet)."""
    schema = json.loads(form_row["schema"])
    layout = formgen.compute_layout(schema)
    page = omr.align_page(img, layout)
    if layout["mode"] == "rows":
        people = omr.read_rows(page, layout)
        if not people:
            raise omr.ScanError("No filled-in rows were found on this sheet. Is it blank, or the wrong form?")
    else:
        people = [{"row": None, "answers": omr.read_single(page, layout)}]
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    fname = f"{stamp}.jpg"
    cv2.imwrite(str(db.DATA_DIR / "scans" / fname), page, [cv2.IMWRITE_JPEG_QUALITY, 85])   # the straightened page
    con = db.connect()
    records = []
    for p in people:
        answers = p["answers"]
        gender, type_, time_in = _derive(schema, answers)
        flags = {k: v["flags"] for k, v in answers.items() if v["flags"]}
        sel = {k: v["selected"] for k, v in answers.items()}
        cur = con.execute(
            "INSERT INTO records (form_id,answers,gender,type,time_in,scan_file,needs_review,flags,row_no,sheet_id) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (form_row["id"], json.dumps(sel), gender, type_, time_in, fname, 1 if flags else 0, json.dumps(flags), p["row"], fname))
        records.append({"record_id": cur.lastrowid, "row": p["row"], "answers": sel, "flags": flags, "needs_review": bool(flags)})
    con.commit()
    con.close()
    exporter.schedule()
    first = records[0]
    return {"file": label, "ok": True, "sheet": layout["mode"] == "rows", "people": len(records), "records": records,
            "write_ids": [f["id"] for f in schema["fields"] if f.get("type") == "write"],
            "record_id": first["record_id"], "record_ids": [r["record_id"] for r in records],
            "needs_review": any(r["needs_review"] for r in records), "review_count": sum(1 for r in records if r["needs_review"]),
            "flags": first["flags"] if len(records) == 1 else {}, "answers": first["answers"] if len(records) == 1 else {}}


def _tally(results: list[dict]) -> tuple[int, int, int]:
    """(registrations read, pages that failed, registrations needing review) for the history line."""
    ok = sum(r.get("people", 1) for r in results if r["ok"])
    failed = sum(1 for r in results if not r["ok"])
    review = sum(r.get("review_count", 1 if r.get("needs_review") else 0) for r in results if r["ok"])
    return ok, failed, review


@app.post("/api/scan", dependencies=[Depends(current_user)])
async def scan(form_id: int = Form(...), files: list[UploadFile] = File(...),
               batch: str | None = Form(None), user: str = Depends(current_user)):
    form_row = _get_form(form_id)
    results = []
    for up in files:
        data = await up.read()
        try:
            pages = omr.load_images(data, up.filename or "")
        except omr.ScanError as e:
            results.append({"file": up.filename, "ok": False, "error": str(e)})
            continue
        for i, page in enumerate(pages):
            label = up.filename if len(pages) == 1 else f"{up.filename} (page {i + 1})"
            try:
                results.append(process_image(form_row, page, label))
            except omr.ScanError as e:
                results.append({"file": label, "ok": False, "error": str(e)})
    db.log_scan(user, "web", batch, *_tally(results))
    return {"results": results}


@app.get("/api/scanners", dependencies=[Depends(current_user)])
async def scanners():
    """Scanners connected to this computer (found through Windows), plus where the inbox folder is."""
    try:
        devices = await run_in_threadpool(scanner.list_devices)
    except scanner.ScannerError as e:
        raise HTTPException(502, str(e))
    return {"devices": devices, "supported": scanner.supported(), "inbox": str(db.DATA_DIR / "inbox")}


class ScannerScan(BaseModel):
    form_id: int
    device_id: str
    dpi: int = 200
    feeder: bool = False
    batch: str | None = None


@app.post("/api/scanners/scan")
async def scanner_scan(body: ScannerScan, user: str = Depends(current_user)):
    """Scan from the printer's scanner, read the page(s) with the chosen form, and save the results."""
    form_row = _get_form(body.form_id)
    try:
        files = await run_in_threadpool(scanner.scan, body.device_id, body.dpi, body.feeder)
    except scanner.ScannerError as e:
        raise HTTPException(502, str(e))
    results = []
    for path in files:
        try:
            for page in omr.load_images(path.read_bytes(), path.name):
                try:
                    results.append(process_image(form_row, page, "Scanned page"))
                except omr.ScanError as e:
                    results.append({"file": "Scanned page", "ok": False, "error": str(e)})
        except omr.ScanError as e:
            results.append({"file": "Scanned page", "ok": False, "error": str(e)})
        finally:
            shutil.rmtree(path.parent, ignore_errors=True)
    for i, r in enumerate(results):
        if len(results) > 1:
            r["file"] = f"Page {i + 1}"
    db.log_scan(user, "scanner", body.batch, *_tally(results))
    return {"results": results}


_lock_file = None


def _try_lock() -> bool:
    """Only one running copy (browser version or desktop app) may watch the inbox at a time, or two
    copies would race for the same files. The lock is held until this process exits; a waiting
    copy then takes over."""
    global _lock_file
    try:
        import msvcrt
    except ImportError:  # not Windows: no lock
        return True
    try:
        if _lock_file is None:
            _lock_file = open(db.DATA_DIR / ".inbox.lock", "a+")
        _lock_file.seek(0)
        msvcrt.locking(_lock_file.fileno(), msvcrt.LK_NBLCK, 1)
        return True
    except OSError:
        return False


def _watch_inbox():
    """Process any image/PDF that lands in data/inbox using the active form."""
    inbox = db.DATA_DIR / "inbox"
    have_lock = False
    while True:
        if not have_lock:
            have_lock = _try_lock()
            if not have_lock:
                time.sleep(5)
                continue
        try:
            for p in sorted(inbox.glob("*")):
                if p.suffix.lower() not in (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".pdf"):
                    continue
                if time.time() - p.stat().st_mtime < 2:  # still being written
                    continue
                con = db.connect()
                form_row = con.execute("SELECT * FROM forms WHERE active=1").fetchone()
                con.close()
                if form_row:
                    got = []
                    try:
                        for page in omr.load_images(p.read_bytes(), p.name):
                            got.append(process_image(form_row, page, p.name))
                        dest = inbox / "done"
                    except Exception:
                        dest = inbox / "failed"
                    ok, _failed, review = _tally(got)
                    db.log_scan("inbox", "inbox", f"inbox-{int(time.time() // 30)}",  # files read within the same 30s share one history row
                                ok, 1 if dest.name == "failed" else 0, review)
                    dest.mkdir(exist_ok=True)
                    p.replace(dest / p.name)
        except Exception:
            pass
        time.sleep(3)


@app.get("/api/scans/{name}", dependencies=[Depends(current_user)])
def scan_image(name: str):
    path = db.DATA_DIR / "scans" / Path(name).name
    if not path.exists():
        raise HTTPException(404)
    return FileResponse(path)


# ---------- records ----------
def _rec(r):
    return {"id": r["id"], "form_id": r["form_id"], "created_at": r["created_at"], "gender": r["gender"],
            "type": r["type"], "time_in": r["time_in"], "row_no": r["row_no"], "needs_review": bool(r["needs_review"]),
            "scan_file": r["scan_file"], "answers": json.loads(r["answers"] or "{}"), "flags": json.loads(r["flags"] or "{}")}


@app.get("/api/records/{rid}/image", dependencies=[Depends(current_user)])
def record_image(rid: int):
    """The scan behind a record. For a multi-row sheet: just that person's row, under the column headings."""
    con = db.connect()
    r = con.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
    form = con.execute("SELECT schema FROM forms WHERE id=?", (r["form_id"],)).fetchone() if r else None
    con.close()
    if not r or not r["scan_file"]:
        raise HTTPException(404)
    path = db.DATA_DIR / "scans" / Path(r["scan_file"]).name
    if not path.exists():
        raise HTTPException(404, "The scan file is no longer on this computer")
    if r["row_no"] is None or not form:
        return FileResponse(path)
    layout = formgen.compute_layout(json.loads(form["schema"]))
    page = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    rd = layout["rows_data"][r["row_no"] - 1]
    h = layout["row_h"]
    x0, x1 = max(0, layout["left"] - 12), min(layout["width"], layout["x_end"] + 12)
    header = page[290:layout["y0"], x0:x1]
    band = page[max(0, rd["cy"] - h // 2):rd["cy"] + h // 2, x0:x1]
    mark = band.copy()
    cv2.rectangle(mark, (0, 0), (mark.shape[1] - 1, mark.shape[0] - 1), 0, 3)    # frame the person's row
    out = cv2.vconcat([header, mark])
    ok, buf = cv2.imencode(".jpg", out, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return Response(buf.tobytes(), media_type="image/jpeg")


@app.get("/api/months", dependencies=[Depends(current_user)])
def months():
    con = db.connect()
    rows = con.execute("SELECT substr(created_at,1,7) m, COUNT(*) n FROM records GROUP BY m ORDER BY m DESC").fetchall()
    con.close()
    return [{"month": r["m"], "count": r["n"]} for r in rows]


@app.get("/api/records", dependencies=[Depends(current_user)])
def records(month: str | None = None, needs_review: bool | None = None):
    q, args = "SELECT * FROM records WHERE 1=1", []
    if month:
        q += " AND substr(created_at,1,7)=?"
        args.append(month)
    if needs_review is not None:
        q += " AND needs_review=?"
        args.append(1 if needs_review else 0)
    con = db.connect()
    rows = con.execute(q + " ORDER BY id", args).fetchall()
    con.close()
    return [_rec(r) for r in rows]


class RecordEdit(BaseModel):
    answers: dict[str, list[str]]


@app.put("/api/records/{rid}", dependencies=[Depends(current_user)])
def edit_record(rid: int, body: RecordEdit, user: str = Depends(current_user)):
    con = db.connect()
    r = con.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
    if not r:
        con.close()
        raise HTTPException(404)
    schema = json.loads(con.execute("SELECT schema FROM forms WHERE id=?", (r["form_id"],)).fetchone()["schema"])
    # text typed in for a written-in box (optional, so it shows up in exports); keep it short and tidy
    typed = {f["id"] for f in schema["fields"] if f.get("type") == "write"}
    answers = {k: ([s.strip()[:200] for s in v if s.strip()] if k in typed else v) for k, v in body.answers.items()}
    gender, type_, time_in = _derive(schema, {k: {"selected": v} for k, v in answers.items()})
    con.execute("UPDATE records SET answers=?, gender=?, type=?, time_in=?, needs_review=0, flags='{}' WHERE id=?",
                (json.dumps(answers), gender, type_, time_in, rid))
    con.commit()
    con.close()
    exporter.schedule()
    db.log(user, "record_edit", f"Corrected answers on record #{rid}" + (" (was flagged for review)" if r["needs_review"] else ""))
    return {"ok": True}


@app.delete("/api/records/{rid}", dependencies=[Depends(current_user)])
def delete_record(rid: int, user: str = Depends(current_user)):
    con = db.connect()
    n = con.execute("DELETE FROM records WHERE id=?", (rid,)).rowcount
    con.commit()
    con.close()
    if n:
        db.log(user, "record_delete", f"Deleted record #{rid}", "warn")
        exporter.schedule()
    return {"ok": True}


@app.delete("/api/months/{month}", dependencies=[Depends(current_user)])
def delete_month(month: str, user: str = Depends(current_user)):
    con = db.connect()
    n = con.execute("DELETE FROM records WHERE substr(created_at,1,7)=?", (month,)).rowcount
    con.commit()
    con.close()
    db.log(user, "month_delete", f"Deleted all {n} records for {month}", "warn")
    exporter.schedule()
    return {"ok": True}


# ---------- export (Excel / CSV) ----------
def _export_info() -> dict:
    s = exporter.settings()
    return {"enabled": s["enabled"], "folder": s["folder"], "csv": s["csv"], "xlsx": s["xlsx"],
            "files": {"csv": str(Path(s["folder"]) / (exporter.FILE_BASE + ".csv")), "xlsx": str(Path(s["folder"]) / (exporter.FILE_BASE + ".xlsx"))},
            "status": s["status"], "database": str(db.DB_PATH), "default_folder": exporter.default_folder()}


class ExportSettings(BaseModel):
    enabled: bool | None = None
    folder: str | None = None
    csv: bool | None = None
    xlsx: bool | None = None


@app.get("/api/export", dependencies=[Depends(current_user)])
def export_get():
    return _export_info()


@app.put("/api/export", dependencies=[Depends(current_user)])
def export_put(body: ExportSettings, user: str = Depends(current_user)):
    new = body.model_dump(exclude_none=True)
    if "folder" in new:
        new["folder"] = new["folder"].strip().strip('"') or exporter.default_folder()
    try:
        exporter.save_settings(new)
    except exporter.ExportError as e:
        raise HTTPException(400, str(e))
    exporter.schedule(0.5)
    return _export_info()


@app.post("/api/export/run", dependencies=[Depends(current_user)])
async def export_run(user: str = Depends(current_user)):
    result = await run_in_threadpool(exporter.run, True)
    db.log(user, "export", f"Exported {result['count']} registrations" + ("" if not result["errors"] else " (with problems)"),
           "warn" if result["errors"] else "info")
    return {"result": result, **_export_info()}


@app.post("/api/export/open-folder", dependencies=[Depends(current_user)])
def export_open_folder():
    folder = Path(exporter.settings()["folder"])
    try:
        folder.mkdir(parents=True, exist_ok=True)
        os.startfile(str(folder))   # Windows: opens File Explorer
    except (OSError, AttributeError) as e:
        raise HTTPException(500, f"Could not open the folder: {e}")
    return {"ok": True}


_KINDS = {"scans": ("scan",), "edits": ("record_edit", "record_delete", "month_delete"),
          "forms": ("form_create", "form_update", "form_activate", "form_delete"), "exports": ("export",)}


@app.get("/api/activity", dependencies=[Depends(current_user)])
def activity(limit: int = 100, before_id: int | None = None, kind: str | None = None, source: str | None = None):
    q, args = "SELECT * FROM activity WHERE 1=1", []
    if kind in _KINDS:
        q += f" AND action IN ({','.join('?' * len(_KINDS[kind]))})"
        args += _KINDS[kind]
    if source:
        q += " AND source=?"
        args.append(source)
    if before_id:
        q += " AND id<?"
        args.append(before_id)
    con = db.connect()
    rows = con.execute(q + " ORDER BY id DESC LIMIT ?", args + [max(1, min(limit, 500))]).fetchall()
    con.close()
    return [{"id": r["id"], "ts": r["ts"], "user": r["user"], "action": r["action"], "detail": r["detail"],
             "level": r["level"], "source": r["source"]} for r in rows]


@app.get("/api/stats", dependencies=[Depends(current_user)])
def stats():
    con = db.connect()
    total = con.execute("SELECT COUNT(*) FROM records").fetchone()[0]
    last = con.execute("SELECT MAX(created_at) FROM records").fetchone()[0]
    today = con.execute("SELECT COUNT(*) FROM records WHERE substr(created_at,1,10)=date('now','localtime')").fetchone()[0]
    review = con.execute("SELECT COUNT(*) FROM records WHERE needs_review=1").fetchone()[0]
    by_type = {r["t"]: r["n"] for r in con.execute(
        "SELECT COALESCE(type,'Unknown') t, COUNT(*) n FROM records GROUP BY t")}
    by_gender = {r["t"]: r["n"] for r in con.execute(
        "SELECT COALESCE(gender,'Unknown') t, COUNT(*) n FROM records GROUP BY t")}
    year = datetime.now().year
    monthly = {}
    for r in con.execute("SELECT substr(created_at,1,7) m, COALESCE(type,'Unknown') t, COUNT(*) n FROM records "
                         "WHERE substr(created_at,1,4)=? GROUP BY m, t", (str(year),)):
        monthly.setdefault(r["t"], [0] * 12)[int(r["m"][5:7]) - 1] = r["n"]
    con.close()
    return {"total": total, "last_scan": last, "today": today, "needs_review": review,
            "by_type": by_type, "by_gender": by_gender, "monthly": monthly, "year": year}


# ---------- serve built frontend (optional) ----------
if getattr(sys, "frozen", False):  # PyInstaller bundle
    _dist = Path(sys._MEIPASS) / "frontend" / "dist"
else:
    _dist = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if _dist.exists():
    app.mount("/", StaticFiles(directory=_dist, html=True), name="web")
