@echo off
rem FA-Scan setup: run this once on a computer. It installs Python (if needed), the packages FA-Scan uses,
rem and puts an FA-Scan icon on the desktop. Needs internet the first time. Safe to run again.
rem This version works with Windows Smart App Control, because it only runs Windows' own signed Python.
setlocal
cd /d "%~dp0"
title FA-Scan setup
echo.
echo  FA-Scan setup
echo  -------------
echo  This takes a few minutes the first time and needs the internet.
echo.

rem ---- 1. Python ------------------------------------------------------------------------------
set "PY="
py -3 -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul && set "PY=python"
if not defined PY if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PY=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PY (
  echo [1/4] Installing Python 3.12 ...
  winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PY=%LocalAppData%\Programs\Python\Python312\python.exe"
)
if not defined PY (
  echo.
  echo  Python could not be installed automatically.
  echo  Please install Python 3.12 from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^),
  echo  then run Setup.bat again.
  goto :fail
)
echo [1/4] Python found.

rem ---- 2. FA-Scan's own Python environment --------------------------------------------------------
if not exist "backend\.venv\Scripts\pythonw.exe" (
  echo [2/4] Creating the FA-Scan environment ...
  %PY% -m venv "backend\.venv" || goto :fail
) else (
  echo [2/4] FA-Scan environment already exists.
)

rem ---- 3. Packages ---------------------------------------------------------------------------------
echo [3/4] Installing packages (about 200 MB the first time) ...
"backend\.venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r "backend\requirements.txt" || goto :fail

rem ---- 4. Website files + desktop icon ----------------------------------------------------------
if not exist "frontend\dist\index.html" (
  echo.
  echo  The website files ^(frontend\dist^) are missing from this folder, so this copy is incomplete.
  echo  Ask for the full FA-Scan package again.
  goto :fail
)
if not defined FASCAN_SETUP_NO_SHORTCUT (
  echo [4/4] Putting an FA-Scan icon on the desktop ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=(Get-Location).Path; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\FA-Scan.lnk'); $s.TargetPath=$d+'\backend\.venv\Scripts\pythonw.exe'; $s.Arguments='launcher.py'; $s.WorkingDirectory=$d+'\backend'; $s.IconLocation=$d+'\backend\assets\icon.ico'; $s.Description='FA-Scan'; $s.Save()"
) else (
  echo [4/4] Skipping the desktop icon.
)

echo.
echo  Setup is done. Open FA-Scan with the desktop icon, or by double-clicking FA-Scan.bat.
if not defined FASCAN_SETUP_NO_LAUNCH (
  echo  Starting FA-Scan now ...
  pushd backend
  start "" ".venv\Scripts\pythonw.exe" launcher.py
  popd
)
echo.
if not defined FASCAN_SETUP_NO_LAUNCH pause
exit /b 0

:fail
echo.
echo  Setup stopped. Read the messages above, fix the problem, and run Setup.bat again.
if not defined FASCAN_SETUP_NO_LAUNCH pause
exit /b 1
