"""Automatic export of registrations to Excel / CSV files.

Every change to the records schedules a refresh a couple of seconds later (so a batch of scans is
written once). The files always contain the full, current list, so edits and deletes are reflected too.
"""
import csv
import json
import os
import threading
from datetime import datetime
from pathlib import Path

from . import db

FILE_BASE = "FA-Scan registrations"


class ExportError(Exception):
    pass


def default_folder() -> str:
    env = os.environ.get("FASCAN_EXPORT_DIR")
    return env if env else str(Path.home() / "Documents" / "FA-Scan Exports")


def settings() -> dict:
    """Current export settings, with defaults filled in."""
    return {
        "enabled": db.get_setting("export_enabled", True),
        "folder": db.get_setting("export_folder", None) or default_folder(),
        "csv": db.get_setting("export_csv", True),
        "xlsx": db.get_setting("export_xlsx", True),
        "status": db.get_setting("export_status", {}),
    }


def save_settings(new: dict):
    mapping = {"enabled": "export_enabled", "folder": "export_folder", "csv": "export_csv", "xlsx": "export_xlsx"}
    db.set_settings({mapping[k]: v for k, v in new.items() if k in mapping and v is not None})


def build_table() -> tuple[list[str], list[list]]:
    """Header and rows for every registration, with one column per form question."""
    con = db.connect()
    forms = {r["id"]: (r["name"], json.loads(r["schema"])["fields"]) for r in con.execute("SELECT id,name,schema FROM forms")}
    labels: list[str] = []
    for _name, fields in forms.values():
        for f in fields:
            if f["label"] not in labels:
                labels.append(f["label"])
    header = ["ID", "Date", "Time", "Form", "Source", "Sheet row", *labels, "Needs review"]
    rows = []
    for r in con.execute("SELECT * FROM records ORDER BY id"):
        name, fields = forms.get(r["form_id"], ("(deleted form)", []))
        answers = json.loads(r["answers"] or "{}")
        by_label = {f["label"]: ", ".join(answers.get(f["id"], [])) for f in fields}
        date, _, tm = (r["created_at"] or "").partition(" ")
        rows.append([r["id"], date, tm[:8], name, "Google Form file" if r["source"] == "import" else "Scanned", r["row_no"] or "", *[by_label.get(l, "") for l in labels],
                     "Yes" if r["needs_review"] else ""])
    con.close()
    return header, rows


def _atomic(path: Path, writer):
    tmp = path.with_name(path.name + ".tmp")
    try:
        writer(tmp)
        os.replace(tmp, path)
    except PermissionError:
        tmp.unlink(missing_ok=True)
        raise ExportError(f"“{path.name}” is open in another program. Close it and the next change will update it.")
    except OSError as e:
        tmp.unlink(missing_ok=True)
        raise ExportError(f"Could not write “{path.name}”: {e.strerror or e}")


def write_csv(path: Path, header, rows):
    def w(tmp):
        with open(tmp, "w", newline="", encoding="utf-8-sig") as f:   # BOM so Excel reads accents correctly
            cw = csv.writer(f)
            cw.writerow(header)
            cw.writerows(rows)
    _atomic(path, w)


def write_xlsx(path: Path, header, rows):
    import xlsxwriter

    def w(tmp):
        wb = xlsxwriter.Workbook(str(tmp))
        ws = wb.add_worksheet("Registrations")
        bold = wb.add_format({"bold": True, "bg_color": "#E8FFE5", "border": 1})
        for c, h in enumerate(header):
            ws.write(0, c, h, bold)
        for r, row in enumerate(rows, 1):
            for c, v in enumerate(row):
                ws.write(r, c, v)
        ws.freeze_panes(1, 0)
        ws.autofilter(0, 0, max(len(rows), 1), len(header) - 1)
        for c, h in enumerate(header):
            width = max([len(str(h))] + [len(str(r[c])) for r in rows[:500]])
            ws.set_column(c, c, min(max(width + 2, 8), 40))
        wb.close()
    _atomic(path, w)


def run(manual: bool = False) -> dict:
    """Write the files now. `manual` ignores the on/off switch (the Export now button)."""
    s = settings()
    header, rows = build_table()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out = {"at": now, "count": len(rows), "files": {}, "errors": {}}
    if manual or s["enabled"]:
        folder = Path(s["folder"])
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            out["errors"]["files"] = f"Could not use the folder {folder}: {e.strerror or e}"
        else:
            for kind, writer, ext in (("csv", write_csv, ".csv"), ("xlsx", write_xlsx, ".xlsx")):
                if not s[kind]:
                    continue
                try:
                    writer(folder / (FILE_BASE + ext), header, rows)
                    out["files"][kind] = str(folder / (FILE_BASE + ext))
                except ExportError as e:
                    out["errors"][kind] = str(e)
                except ImportError:
                    out["errors"][kind] = "The Excel writer is not installed."
        db.set_settings({"export_status": {"files": {"at": now, "count": len(rows), "files": out["files"],
                                                      "error": "; ".join(out["errors"].values()) or None}}})
    return out


# --- automatic refresh after changes -------------------------------------------------------------
_timer = None
_timer_lock = threading.Lock()


def schedule(delay: float = 2.0):
    """Refresh the files shortly after the records change (many scans in a row = one refresh)."""
    global _timer
    try:
        if not settings()["enabled"]:
            return
    except Exception:
        return
    with _timer_lock:
        if _timer:
            _timer.cancel()
        _timer = threading.Timer(delay, _job)
        _timer.daemon = True
        _timer.start()


def _job():
    try:
        run()
    except Exception as e:   # never let a failed export disturb scanning
        try:
            db.set_settings({"export_status": {"files": {"at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "error": str(e)}}})
        except Exception:
            pass
