# Used by Setup.bat. Downloads what FA-Scan needs and shows one progress bar with MB downloaded / MB total and the speed.
#   -What python    download the Python installer from python.org, check its signature, install it for this user
#   -What packages  download every package FA-Scan uses (the file list comes from pip itself), then Setup.bat installs them
# Exit code 0 = done. Anything else: Setup.bat falls back to its plain way of installing.
param(
  [Parameter(Mandatory = $true)][ValidateSet('python', 'packages')][string]$What,
  [string]$Python,          # packages: python.exe inside FA-Scan's environment
  [string]$Requirements,    # packages: requirements.txt
  [string]$Out,             # folder the downloads go into
  [switch]$NoInstall        # python: download and check only (for testing)
)
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 }
catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }

$PythonVersion = '3.12.10'   # the last 3.12 release that has a Windows installer
$live = -not [Console]::IsOutputRedirected

function MB([double]$b) { '{0:N1}' -f ($b / 1MB) }

function Draw([double]$done, [double]$total, [double]$bps, [string]$label) {
  if ($total -le 0) { $total = [Math]::Max($done, 1) }
  $pct = [Math]::Min(100, [int][Math]::Floor(100 * $done / $total))
  $eta = ''
  if ($bps -gt 1024 -and $total -gt $done) { $s = [int](($total - $done) / $bps); $eta = '  about {0}:{1:00} left' -f [int][Math]::Floor($s / 60), ($s % 60) }
  $bar = ('#' * [int]($pct * 30 / 100)).PadRight(30, '-')
  $line = '  [{0}] {1,3}%   {2} MB / {3} MB   {4:N1} MB/s{5}' -f $bar, $pct, (MB $done), (MB $total), ($bps / 1MB), $eta
  if ($label) { $line += '   ' + $label }
  if ($live) { [Console]::Write("`r" + $line.PadRight([Math]::Max(78, $line.Length))) }
  elseif ($pct % 10 -eq 0 -and $script:lastPct -ne $pct) { $script:lastPct = $pct; Write-Host $line }
}

function Get-Length([string]$url) {
  try {
    $r = [Net.HttpWebRequest]::Create($url); $r.Method = 'HEAD'; $r.Timeout = 20000; $r.UserAgent = 'FA-Scan-setup'
    $resp = $r.GetResponse(); $n = $resp.ContentLength; $resp.Close(); return [double]$n
  } catch { return 0 }
}

# Downloads a list of @{url; dest; size; sha256} with one overall bar.
function Get-Files($items) {
  New-Item -ItemType Directory -Force $Out | Out-Null
  $total = 0.0; $unknown = 0
  foreach ($i in $items) { if ($i.size -gt 0) { $total += $i.size } else { $unknown++ } }
  $done = 0.0; $t0 = Get-Date; $script:lastPct = -1; $buf = New-Object byte[] 65536; $lastDraw = [DateTime]::MinValue
  foreach ($i in $items) {
    $req = [Net.HttpWebRequest]::Create($i.url); $req.UserAgent = 'FA-Scan-setup'; $req.Timeout = 30000; $req.ReadWriteTimeout = 30000
    $resp = $req.GetResponse(); $in = $resp.GetResponseStream(); $fs = [IO.File]::Create($i.dest)
    try {
      while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
        $fs.Write($buf, 0, $n); $done += $n
        if (((Get-Date) - $lastDraw).TotalMilliseconds -ge 200) {
          $lastDraw = Get-Date; $sec = [Math]::Max(0.2, ((Get-Date) - $t0).TotalSeconds)
          Draw $done $(if ($unknown) { [Math]::Max($total, $done) } else { $total }) ($done / $sec) ''
        }
      }
    } finally { $fs.Close(); $in.Close(); $resp.Close() }
    if ($i.sha256) {
      $h = (Get-FileHash $i.dest -Algorithm SHA256).Hash
      if ($h -ne $i.sha256.ToUpper()) { throw "A downloaded file is damaged: $(Split-Path $i.dest -Leaf)" }
    }
  }
  $sec = [Math]::Max(0.2, ((Get-Date) - $t0).TotalSeconds)
  $final = [Math]::Max($total, $done)
  Draw $final $final ($done / $sec) ''
  if ($live) { [Console]::WriteLine() }
  Write-Host ('  Downloaded {0} MB in {1:N0} seconds.' -f (MB $done), $sec)
}

if ($What -eq 'python') {
  if (-not $Out) { $Out = Join-Path $env:TEMP 'fascan_python' }
  $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
  $file = "python-$PythonVersion-$arch.exe"
  $url = "https://www.python.org/ftp/python/$PythonVersion/$file"
  $dest = Join-Path $Out $file
  Write-Host "  Downloading Python $PythonVersion from python.org ..."
  Get-Files @(@{ url = $url; dest = $dest; size = (Get-Length $url); sha256 = $null })
  $sig = Get-AuthenticodeSignature $dest
  if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
    throw 'The Python installer is not signed by the Python Software Foundation, so it was not run.'
  }
  Write-Host '  The installer is signed by the Python Software Foundation.'
  if ($NoInstall) { exit 0 }
  Write-Host '  Installing Python (about a minute, no window will open) ...'
  $p = Start-Process -FilePath $dest -ArgumentList '/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_launcher=1', 'Include_test=0', 'Include_doc=0' -Wait -PassThru
  Remove-Item $Out -Recurse -Force -ErrorAction SilentlyContinue
  if ($p.ExitCode -ne 0) { throw "The Python installer stopped (code $($p.ExitCode))." }
  exit 0
}

# ---- packages ----
$py = (Resolve-Path $Python).Path; $req = (Resolve-Path $Requirements).Path
$report = Join-Path $env:TEMP 'fascan_pip_report.json'
Remove-Item $report -ErrorAction SilentlyContinue
Write-Host '  Working out what to download ...'
& $py -m pip install --disable-pip-version-check --dry-run --ignore-installed --report $report -q -r $req | Out-Null
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $report)) { throw 'pip could not work out the package list.' }
$rep = Get-Content $report -Raw | ConvertFrom-Json
$items = @()
foreach ($p in $rep.install) {
  $u = $p.download_info.url
  if ($u -notmatch '^https://') { throw 'A package has no download link.' }
  $sha = $null; try { $sha = $p.download_info.archive_info.hashes.sha256 } catch { }
  $items += @{ url = $u; dest = (Join-Path $Out (($u -split '/')[-1])); size = (Get-Length $u); sha256 = $sha }
}
$sum = 0.0; foreach ($i in $items) { $sum += $i.size }
Write-Host ('  {0} files, {1} MB to download.' -f $items.Count, (MB $sum))
Get-Files $items
exit 0
