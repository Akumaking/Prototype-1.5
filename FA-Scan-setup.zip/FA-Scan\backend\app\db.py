import json
import os
import secrets
import sqlite3
import sys
from pathlib import Path

def _default_data_dir() -> Path:
    if getattr(sys, "frozen", False):  # installed desktop app: keep data in the user's profile, which is always writable
        return Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "FA-Scan" / "data"
    return Path(__file__).resolve().parent.parent / "data"


DATA_DIR = Path(os.environ.get("FASCAN_DATA", _default_data_dir()))
DB_PATH = DATA_DIR / "fa_scan.db"

DEFAULT_SCHEMA = {
    "fields": [
        {"id": "gender", "label": "Gender", "type": "single", "role": "gender", "options": ["Female", "Male"]},
        {"id": "type", "label": "Registrant Type", "type": "single", "role": "type",
         "options": ["Student", "LGU", "Visitor", "Others"]},
    ]
}

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (id_number TEXT PRIMARY KEY, name TEXT, salt TEXT, pw_hash TEXT);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, id_number TEXT);
CREATE TABLE IF NOT EXISTS forms (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, title TEXT, schema TEXT,
  active INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT DEFAULT (datetime('now','localtime')), user TEXT, action TEXT,
  detail TEXT, level TEXT DEFAULT 'info', source TEXT DEFAULT 'web', batch TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS records (
  id INTEGER PRIMARY KEY AUTOINCREMENT, form_id INTEGER, created_at TEXT DEFAULT (datetime('now','localtime')),
  answers TEXT, gender TEXT, type TEXT, scan_file TEXT, needs_review INTEGER DEFAULT 0, flags TEXT,
  time_in TEXT, row_no INTEGER, sheet_id TEXT);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
"""

# columns added after the first release; older databases get them on start
_ADDED_COLUMNS = [("time_in", "TEXT"), ("row_no", "INTEGER"), ("sheet_id", "TEXT")]


def get_setting(key: str, default=None):
    con = connect()
    row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    con.close()
    if row is None:
        return default
    try:
        return json.loads(row["value"])
    except ValueError:
        return row["value"]


def set_settings(values: dict):
    con = connect()
    for k, v in values.items():
        con.execute("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, json.dumps(v)))
    con.commit()
    con.close()


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def _who(con, user: str) -> str:
    row = con.execute("SELECT name FROM users WHERE id_number=?", (user,)).fetchone()
    return f"{row['name']} ({user})" if row else user


def log(user: str, action: str, detail: str, level: str = "info", source: str = "web"):
    """Append an entry to the activity history."""
    con = connect()
    con.execute("INSERT INTO activity (user,action,detail,level,source) VALUES (?,?,?,?,?)",
                (_who(con, user), action, detail, level, source))
    con.commit()
    con.close()


def _scan_text(d: dict, source: str) -> str:
    via = {"inbox": " from the inbox folder", "scanner": " from the scanner"}.get(source, " by upload")
    parts = [f"{d['ok']} registration{'s' if d['ok'] != 1 else ''} read{via}"]
    if d["review"]:
        parts.append(f"{d['review']} need review")
    if d["failed"]:
        parts.append(f"{d['failed']} could not be read")
    return ", ".join(parts)


def log_scan(user: str, source: str, batch: str | None, ok: int, failed: int, review: int):
    """One history row per scanning batch; later calls with the same batch id update that row."""
    if not (ok or failed):
        return
    con = connect()
    row = con.execute("SELECT id, data FROM activity WHERE batch=?", (batch,)).fetchone() if batch else None
    d = json.loads(row["data"]) if row else {"ok": 0, "failed": 0, "review": 0}
    d["ok"] += ok; d["failed"] += failed; d["review"] += review
    level = "warn" if (d["review"] or d["failed"]) else "info"
    if row:
        con.execute("UPDATE activity SET detail=?, level=?, data=?, ts=datetime('now','localtime') WHERE id=?",
                    (_scan_text(d, source), level, json.dumps(d), row["id"]))
    else:
        con.execute("INSERT INTO activity (user,action,detail,level,source,batch,data) VALUES (?,?,?,?,?,?,?)",
                    (_who(con, user) if source != "inbox" else "Inbox folder", "scan", _scan_text(d, source), level, source,
                     batch, json.dumps(d)))
    con.commit()
    con.close()


def init_db():
    con = connect()
    con.executescript(SCHEMA_SQL)
    have = {r["name"] for r in con.execute("PRAGMA table_info(records)")}
    for name, ddl in _ADDED_COLUMNS:
        if name not in have:
            con.execute(f"ALTER TABLE records ADD COLUMN {name} {ddl}")
    if not con.execute("SELECT 1 FROM users").fetchone():
        # The app has no sign-in screen; this single local user is only the name shown in History.
        salt = secrets.token_hex(8)
        con.execute("INSERT INTO users VALUES (?,?,?,?)", ("0001", "Admin", salt, secrets.token_hex(16)))
    con.execute("DELETE FROM sessions")   # old sign-in tokens are no longer used
    con.execute("DELETE FROM settings WHERE key LIKE 'gsheet_%'")   # Google Sheets sync was removed; forget any saved address
    if not con.execute("SELECT 1 FROM forms").fetchone():
        con.execute("INSERT INTO forms (name,title,schema,active) VALUES (?,?,?,1)",
                    ("Registration Form", "Registration Form", json.dumps(DEFAULT_SCHEMA)))
    con.commit()
    con.close()
