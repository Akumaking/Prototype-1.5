"""Bring in registrations that were collected somewhere else, e.g. the answers of a Google Form that were
downloaded from its linked Google Sheet as CSV or Excel. Works completely offline on the file you give it."""
from __future__ import annotations

import csv
import difflib
import hashlib
import io
import re
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

MAX_BYTES = 10 * 1024 * 1024
MAX_ROWS = 20000


class ImportError_(Exception):
    """A problem with the file the person chose (shown to them as is)."""


# ---------- a Google Sheet link (live sync) ----------
_GOOGLE_HOSTS = ("google.com", "googleusercontent.com")


def _google_url(url: str) -> bool:
    p = urllib.parse.urlparse(url)
    h = (p.hostname or "").lower()
    return p.scheme == "https" and any(h == g or h.endswith("." + g) for g in _GOOGLE_HOSTS)


def normalize_sheet_url(url: str) -> str:
    """Turn what people paste into a link that returns the sheet as CSV.
    Accepts 'Publish to web' CSV links and 'Anyone with the link can view' sheet links; nothing else."""
    url = (url or "").strip()
    p = urllib.parse.urlparse(url)
    if p.scheme != "https" or (p.hostname or "").lower() != "docs.google.com" or "/spreadsheets/d/" not in p.path:
        raise ImportError_("That doesn't look like a Google Sheets link. It should start with https://docs.google.com/spreadsheets/")
    q = urllib.parse.parse_qs(p.query)
    frag = urllib.parse.parse_qs(p.fragment)
    if "/spreadsheets/d/e/" in p.path:                                    # File → Share → Publish to web
        path = re.sub(r"/pub(html)?$", "/pub", p.path)
        if not path.endswith("/pub"):
            path = path.rstrip("/") + "/pub"
        keep = {k: v[0] for k, v in q.items() if k in ("gid", "single")}
        keep["output"] = "csv"
        return urllib.parse.urlunparse(("https", "docs.google.com", path, "", urllib.parse.urlencode(keep), ""))
    m = re.search(r"/spreadsheets/d/([A-Za-z0-9_-]+)", p.path)           # a normal link to the sheet
    if not m:
        raise ImportError_("That doesn't look like a Google Sheets link.")
    keep = {"format": "csv"}
    gid = (q.get("gid") or frag.get("gid") or [None])[0]
    if gid:
        keep["gid"] = gid
    return f"https://docs.google.com/spreadsheets/d/{m.group(1)}/export?{urllib.parse.urlencode(keep)}"


class _SameCompany(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _google_url(newurl):
            raise ImportError_("The link led somewhere that is not Google, so it was not opened.")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_sheet(url: str, timeout: int = 25) -> bytes:
    """Download the sheet as CSV. Only ever talks to Google, and sends nothing but the link itself."""
    url = normalize_sheet_url(url)
    opener = urllib.request.build_opener(_SameCompany)
    req = urllib.request.Request(url, headers={"User-Agent": "FA-Scan"})
    try:
        with opener.open(req, timeout=timeout) as r:
            data = r.read(MAX_BYTES + 1)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403, 404):
            raise ImportError_("Google would not give out this sheet. Publish it to the web (File → Share → Publish to web) "
                               "or set it to “Anyone with the link can view”, then try again.")
        raise ImportError_(f"Google answered with an error ({e.code}). Try again in a moment.")
    except (urllib.error.URLError, OSError):
        raise ImportError_("Could not reach Google. Check the internet connection.")
    if len(data) > MAX_BYTES:
        raise ImportError_("The sheet is too large to read (limit 10 MB).")
    if data.lstrip()[:15].lower().startswith((b"<!doctype", b"<html")):
        raise ImportError_("Google asked for a sign-in instead of giving the sheet. Publish it to the web (File → Share → "
                           "Publish to web) or set it to “Anyone with the link can view”.")
    return data


# ---------- reading the file ----------
def _clean(v) -> str:
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if hasattr(v, "isoformat"):          # date / time objects from Excel
        return v.isoformat(sep=" ")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _unique(headers: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    out = []
    for i, h in enumerate(headers):
        h = h.strip() or f"Column {i + 1}"
        n = seen.get(h, 0) + 1
        seen[h] = n
        out.append(h if n == 1 else f"{h} ({n})")
    return out


def _read_csv(data: bytes) -> list[list[str]]:
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ImportError_("This file could not be read as text. Download it again as CSV or Excel.")
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    return [[_clean(c) for c in row] for row in csv.reader(io.StringIO(text), dialect)]


def _read_xlsx(data: bytes) -> list[list[str]]:
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise ImportError_("Excel files need one more component. Download the answers as CSV instead, or run Setup again.")
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb.worksheets[0]
        return [[_clean(c) for c in row] for row in ws.iter_rows(values_only=True)]
    except Exception:
        raise ImportError_("This Excel file could not be opened. Download it again from Google Sheets (File → Download).")


def read_table(data: bytes, filename: str) -> tuple[list[str], list[dict[str, str]]]:
    """(headers, rows as {header: text}). The first row of the file is the header row."""
    if len(data) > MAX_BYTES:
        raise ImportError_("This file is too large (limit 10 MB).")
    if data[:2] == b"PK":                                   # .xlsx is a zip file
        table = _read_xlsx(data)
    elif filename.lower().endswith((".xls", ".ods")):
        raise ImportError_("Please download the answers as CSV or Excel (.xlsx).")
    else:
        table = _read_csv(data)
    table = [r for r in table if any(c for c in r)]
    if len(table) < 2:
        raise ImportError_("No answers were found in this file. The first row must be the question headings, with answers below.")
    headers = _unique(table[0])
    rows = []
    for r in table[1:]:
        r = (r + [""] * len(headers))[:len(headers)]
        rows.append(dict(zip(headers, r)))
    if len(rows) > MAX_ROWS:
        raise ImportError_(f"This file has more than {MAX_ROWS} answers. Split it into smaller files.")
    return headers, rows


# ---------- matching the file's columns to the form's questions ----------
def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def suggest_mapping(fields: list[dict], headers: list[str]) -> tuple[dict[str, str | None], str | None]:
    """Guess which column answers which question, and which column holds the date and time."""
    ts = next((h for h in headers if norm(h) == "timestamp"), None) or next((h for h in headers if "timestamp" in norm(h)), None)
    free = [h for h in headers if h != ts]
    mapping: dict[str, str | None] = {}
    for f in fields:                                         # exact name first, so a close match can't steal it
        hit = next((h for h in free if norm(h) == norm(f["label"])), None)
        if hit:
            mapping[f["id"]] = hit
            free.remove(hit)
    for f in fields:
        if f["id"] in mapping:
            continue
        n = norm(f["label"])
        best, score = None, 0.0
        for h in free:
            hn = norm(h)
            r = 0.9 if n and (n in hn or hn in n) else difflib.SequenceMatcher(None, n, hn).ratio()
            if r > score:
                best, score = h, r
        if best and score >= 0.6:
            mapping[f["id"]] = best
            free.remove(best)
        else:
            mapping[f["id"]] = None
    return mapping, ts


# ---------- values ----------
_NUM_PREFIX = re.compile(r"^\s*\d+\s*(?:-{1,2}|–|—|\.|\)|:)\s*")


def _strip_num(s: str) -> str:
    """'3 -- Academe' -> 'Academe' (Google Forms options are often numbered)."""
    return _NUM_PREFIX.sub("", s or "", count=1)


def _match_option(text: str, options: list[str]) -> str | None:
    n = norm(text)
    for o in options:                                     # same words
        if norm(o) == n:
            return o
    cands = {n, norm(_strip_num(text))} - {""}
    for o in options:                                     # same words once a leading number is ignored
        if cands & {norm(o), norm(_strip_num(o))} - {""}:
            return o
    return None


def _others_option(options: list[str]) -> str | None:
    """The form's own 'Others' choice: where Google's free-text 'Other' answers go."""
    return next((o for o in options if norm(_strip_num(o)) in ("other", "others")), None)


def _split_many(text: str, options: list[str]) -> tuple[list[str], list[str]]:
    """Google Forms joins checkbox answers with ', '. Options that themselves contain commas still match."""
    tokens = [t.strip() for t in re.split(r"[,;]", text) if t.strip()]
    chosen, bad, i = [], [], 0
    while i < len(tokens):
        for j in range(min(len(tokens), i + 4), i, -1):     # longest run of tokens that is one of the options
            o = _match_option(", ".join(tokens[i:j]), options)
            if o:
                if o not in chosen:
                    chosen.append(o)
                i = j
                break
        else:
            bad.append(tokens[i])
            i += 1
    return chosen, bad


def read_answers(fields: list[dict], mapping: dict[str, str | None], row: dict[str, str]):
    """(answers {field_id: [selected]}, flags {field_id: [text]}, unmatched [(label, value)])."""
    answers: dict[str, list[str]] = {}
    flags: dict[str, list[str]] = {}
    unmatched: list[tuple[str, str]] = []
    for f in fields:
        col = mapping.get(f["id"])
        text = (row.get(col, "") if col else "").strip()
        if f.get("type") == "write":
            answers[f["id"]] = [text[:200]] if text else []
            continue
        options = f.get("options") or []
        if not text:
            answers[f["id"]] = []
            flags[f["id"]] = ["blank"]
        elif f["type"] == "multi":
            chosen, bad = _split_many(text, options)
            oth = _others_option(options)
            if bad and oth:                                  # typed-in "Other" answers count as Others
                if oth not in chosen:
                    chosen.append(oth)
                bad = []
            answers[f["id"]] = chosen
            if bad:
                flags[f["id"]] = [f"unmatched: {b}" for b in bad]
                unmatched += [(f["label"], b) for b in bad]
        else:
            o = _match_option(text, options) or _others_option(options)
            answers[f["id"]] = [o] if o else []
            if not o:
                flags[f["id"]] = [f"unmatched: {text[:60]}"]
                unmatched.append((f["label"], text[:60]))
    return answers, flags, unmatched


# ---------- date and time ----------
_YMD = ("%Y/%m/%d %I:%M:%S %p", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d %I:%M:%S %p", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M", "%Y/%m/%d", "%Y-%m-%d")
_MDY = ("%m/%d/%Y %H:%M:%S", "%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %H:%M", "%m/%d/%Y %I:%M %p", "%m/%d/%Y")
_DMY = ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y %I:%M:%S %p", "%d/%m/%Y %H:%M", "%d/%m/%Y %I:%M %p", "%d/%m/%Y")


def parse_stamp(text: str) -> datetime | None:
    s = re.sub(r"\s*(GMT|UTC)\s*[+-]?\d{0,2}(:?\d{2})?\s*$", "", (text or "").strip())   # "… PM GMT+8"
    s = re.sub(r"\.\d+$", "", s)
    if not s:
        return None
    for group in (_YMD, _MDY, _DMY):                       # month-first is tried before day-first
        for fmt in group:
            try:
                return datetime.strptime(s, fmt)
            except ValueError:
                pass
    return None


def row_key(form_id: int, stamp: str, row: dict[str, str]) -> str:
    raw = "\x1f".join([str(form_id), stamp, *[f"{k}={v}" for k, v in row.items()]])
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()
