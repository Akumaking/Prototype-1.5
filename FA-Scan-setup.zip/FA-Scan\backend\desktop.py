"""FA-Scan desktop app: the same server as the browser version, shown in its own window.

The window is Microsoft Edge (or Chrome) in "app mode": its own window with no tabs or address bar.
That needs no extra program files, so it also works where Windows security (Smart App Control)
refuses to load unsigned helper DLLs. The server stops by itself shortly after the window is closed.
If neither browser is found, the default browser is used.
"""
import ctypes
import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

PREFERRED_PORT = 8750   # fixed so the saved sign-in survives restarts; the browser version uses 8000
GUARD_PORT = 8751       # held while running, so a second launch can't start a second copy

if getattr(sys, "frozen", False):
    sys.path.insert(0, getattr(sys, "_MEIPASS", str(Path(sys.executable).parent)))
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent))


def message(text: str, title: str = "FA-Scan"):
    ctypes.windll.user32.MessageBoxW(0, text, title, 0x40)


def free_port() -> int:
    for port in (PREFERRED_PORT, 0):
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", port))
            return s.getsockname()[1]
        except OSError:
            continue
        finally:
            s.close()
    raise RuntimeError("No free network port")


def main():
    from app.window import open_window
    guard = socket.socket()
    try:
        guard.bind(("127.0.0.1", GUARD_PORT))
    except OSError:
        # Already running: just bring up a window for the running copy.
        from app import db
        if not open_window(f"http://localhost:{PREFERRED_PORT}", db.DATA_DIR / "app-window"):
            message("FA-Scan is already running. Look for its window in the taskbar.")
        return

    os.environ["FASCAN_AUTOCLOSE"] = "1"   # stop the server shortly after the window is closed
    from app import db
    db.DATA_DIR.mkdir(parents=True, exist_ok=True)
    log = open(db.DATA_DIR / "desktop.log", "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log          # a windowed app has no console

    import uvicorn
    from app.main import app
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_config=None))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(150):
        if server.started:
            break
        time.sleep(0.1)
    else:
        message("FA-Scan could not start. See desktop.log in the data folder:\n" + str(db.DATA_DIR))
        return

    url = f"http://localhost:{port}"
    if not open_window(url, db.DATA_DIR / "app-window"):
        webbrowser.open(url)
    while True:                            # the auto-close watcher ends the process when the window is gone
        time.sleep(1)


if __name__ == "__main__":
    main()
