"""Direct scanning through Windows Image Acquisition (WIA), the scanner system built into Windows.

The server runs on the same computer the scanner is connected to, so it can drive the scanner itself.
WIA is driven through Windows PowerShell's COM support, which needs no extra packages and works
inside the packaged desktop app.

For development without hardware, set FASCAN_FAKE_SCANNER to a folder of page images: a pretend
"Test scanner" then hands those images out one by one.
"""
import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import uuid
from pathlib import Path

PNG_FORMAT = "{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}"
ALLOWED_DPI = (100, 150, 200, 300, 600)
_lock = threading.Lock()
_fake_index = 0


class ScannerError(Exception):
    """A problem the person at the desk can understand and fix."""


# WIA error codes -> plain language
FRIENDLY = {
    "80210001": "The scanner reported an unknown error. Turn it off and on, then try again.",
    "80210002": "Paper jam in the scanner.",
    "80210003": "No paper in the document feeder.",
    "80210004": "The scanner has a paper problem. Check the page and try again.",
    "80210005": "The scanner is turned off or not connected. Turn it on, check the USB cable, then press Refresh.",
    "80210006": "The scanner is busy. Wait a moment, close other scanning programs, and try again.",
    "80210007": "The scanner is warming up. Wait a few seconds and try again.",
    "80210009": "The scanner is locked by another program. Close it and try again.",
    "80210015": "No scanner was found. Turn it on, check the USB cable, then press Refresh.",
    "80210016": "The scanner cover is open. Close the lid and try again.",
    "DEVICE_NOT_FOUND": "That scanner is no longer available. Press Refresh and choose it again.",
}

_LIST_SCRIPT = r"""
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$out = @()
try {
  $dm = New-Object -ComObject WIA.DeviceManager
  foreach ($i in $dm.DeviceInfos) {
    if ($i.Type -eq 1) { $out += [pscustomobject]@{ id = [string]$i.DeviceID; name = [string]$i.Properties.Item('Name').Value } }
  }
} catch { }
ConvertTo-Json -InputObject @($out) -Compress
"""

_SCAN_SCRIPT = r"""
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
function Out-Result($o) { ConvertTo-Json -InputObject $o -Compress -Depth 4 }
try {
  $dm = New-Object -ComObject WIA.DeviceManager
  $info = $null
  foreach ($i in $dm.DeviceInfos) { if ($i.DeviceID -eq $env:FASCAN_WIA_DEVICE) { $info = $i } }
  if (-not $info) { throw 'DEVICE_NOT_FOUND' }
  $dev = $info.Connect()
  $dpi = [int]$env:FASCAN_WIA_DPI
  $feeder = ($env:FASCAN_WIA_FEEDER -eq '1')
  try { $dev.Properties.Item('3088').Value = $(if ($feeder) { 1 } else { 2 }) } catch { }   # 1 = feeder, 2 = flatbed
  $files = @()
  $max = $(if ($feeder) { 100 } else { 1 })
  for ($n = 0; $n -lt $max; $n++) {
    $item = $dev.Items.Item(1)
    foreach ($kv in @(@('6147', $dpi), @('6148', $dpi), @('6146', 2))) {   # x/y resolution, intent 2 = grayscale
      try { $item.Properties.Item($kv[0]).Value = $kv[1] } catch { }
    }
    try { $img = $item.Transfer($env:FASCAN_WIA_FORMAT) } catch { if ($feeder -and $n -gt 0) { break } else { throw } }
    $path = Join-Path $env:FASCAN_WIA_OUT ('page_{0}_{1}.png' -f $PID, $n)
    $img.SaveFile($path)
    $files += $path
  }
  Out-Result @{ ok = $true; files = @($files) }
} catch {
  $h = ''
  try { $h = ('{0:X8}' -f ($_.Exception.HResult -band 0xFFFFFFFF)) } catch { }
  Out-Result @{ ok = $false; error = [string]$_.Exception.Message; hresult = $h }
}
"""


def _powershell() -> str:
    root = os.environ.get("SystemRoot", r"C:\Windows")
    exe = Path(root) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(exe) if exe.exists() else (shutil.which("powershell") or "powershell")


def _run(script: str, env_extra: dict, timeout: int) -> str:
    enc = base64.b64encode(script.encode("utf-16-le")).decode()
    env = {**os.environ, **env_extra}
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        r = subprocess.run([_powershell(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                           capture_output=True, timeout=timeout, env=env, creationflags=flags)
    except subprocess.TimeoutExpired:
        raise ScannerError("The scanner took too long to respond. Check that it is on and not busy, then try again.")
    return r.stdout.decode("utf-8", "replace").strip()


def _fake_dir():
    d = os.environ.get("FASCAN_FAKE_SCANNER")
    return Path(d) if d else None


def supported() -> bool:
    return sys.platform == "win32" or _fake_dir() is not None


def list_devices() -> list[dict]:
    """Scanners Windows knows about right now: [{"id", "name"}]."""
    fake = _fake_dir()
    if fake:
        return [{"id": "fake:0", "name": "Test scanner (sample pages)"}]
    if sys.platform != "win32":
        return []
    out = _run(_LIST_SCRIPT, {}, timeout=30)
    try:
        data = json.loads(out) if out else []
    except ValueError:
        return []
    return data if isinstance(data, list) else [data]


def scan(device_id: str, dpi: int = 200, feeder: bool = False) -> list[Path]:
    """Scan one page (or every page in the feeder) and return PNG files. The caller deletes them."""
    if dpi not in ALLOWED_DPI:
        raise ScannerError("Unsupported resolution.")
    if not _lock.acquire(blocking=False):
        raise ScannerError("A scan is already in progress.")
    try:
        fake = _fake_dir()
        if fake:
            return [_fake_page(fake)]
        if sys.platform != "win32":
            raise ScannerError("Direct scanning needs Windows.")
        out_dir = Path(tempfile.mkdtemp(prefix="fascan_scan_"))
        raw = _run(_SCAN_SCRIPT, {"FASCAN_WIA_DEVICE": device_id, "FASCAN_WIA_DPI": str(dpi), "FASCAN_WIA_FEEDER": "1" if feeder else "0",
                                  "FASCAN_WIA_OUT": str(out_dir), "FASCAN_WIA_FORMAT": PNG_FORMAT}, timeout=180)
        try:
            res = json.loads(raw.splitlines()[-1]) if raw else {}
        except ValueError:
            res = {}
        if not res.get("ok"):
            shutil.rmtree(out_dir, ignore_errors=True)
            raise ScannerError(friendly_error(res.get("hresult", ""), res.get("error", "")))
        files = [Path(p) for p in res.get("files", []) if Path(p).exists()]
        if not files:
            shutil.rmtree(out_dir, ignore_errors=True)
            raise ScannerError("The scanner did not return a page. Put the page on the glass and try again.")
        return files
    finally:
        _lock.release()


def friendly_error(hresult: str, message: str = "") -> str:
    key = (hresult or "").upper()
    if key in FRIENDLY:
        return FRIENDLY[key]
    if message in FRIENDLY:
        return FRIENDLY[message]
    return f"The scanner could not scan: {message or 'unknown error'}" + (f" (code {key})" if key else "")


def _fake_page(folder: Path) -> Path:
    """Hand out the next sample page (cycling), as a temp copy so the original is never deleted."""
    global _fake_index
    pages = sorted(p for p in folder.iterdir() if p.suffix.lower() in (".png", ".jpg", ".jpeg"))
    if not pages:
        raise ScannerError("The test scanner folder has no images.")
    src = pages[_fake_index % len(pages)]
    _fake_index += 1
    dest = Path(tempfile.mkdtemp(prefix="fascan_fake_")) / f"{uuid.uuid4().hex}{src.suffix}"
    shutil.copyfile(src, dest)
    return dest
