"""Start FA-Scan with one double-click: runs the server, opens it in its own app-style window, and exits
shortly after the window is closed. Started by FA-Scan.bat (via pythonw, so no console window).

This is the version that works on PCs with Windows Smart App Control, because it only runs Windows' own
signed Python and the well-known packages installed by Setup.bat."""
import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
PORT = int(os.environ.get("FASCAN_PORT", "8000"))
URL = f"http://localhost:{PORT}"


def port_in_use() -> bool:
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


def show():
    """Open the site: an app-style window if Edge/Chrome is available, otherwise the default browser."""
    if os.environ.get("FASCAN_NO_BROWSER"):
        return
    from app import db
    from app.window import open_window
    if not open_window(URL, db.DATA_DIR / "app-window"):
        webbrowser.open(URL)


def open_when_ready():
    for _ in range(100):
        if port_in_use():
            break
        time.sleep(0.2)
    show()


if __name__ == "__main__":
    os.chdir(HERE)
    sys.path.insert(0, str(HERE))
    if port_in_use():            # already running: just open another window onto it
        show()
        sys.exit(0)

    (HERE / "data").mkdir(exist_ok=True)
    log = open(HERE / "data" / "server.log", "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log          # pythonw has no console

    os.environ["FASCAN_AUTOCLOSE"] = "1"
    import uvicorn
    threading.Thread(target=open_when_ready, daemon=True).start()
    uvicorn.run("app.main:app", host="127.0.0.1", port=PORT, log_config=None)
