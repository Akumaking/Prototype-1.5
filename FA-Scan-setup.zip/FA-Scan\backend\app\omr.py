"""Optical mark recognition for forms produced by formgen.py."""
import cv2
import numpy as np

MARKED_THRESHOLD = 0.22  # darkness score above which a circle counts as shaded


class ScanError(Exception):
    pass


def load_images(data: bytes, filename: str) -> list[np.ndarray]:
    """Decode an uploaded image or PDF into a list of BGR page images."""
    if filename.lower().endswith(".pdf") or data[:4] == b"%PDF":
        import pypdfium2 as pdfium
        try:
            doc = pdfium.PdfDocument(data)
        except Exception as e:
            raise ScanError(f"{filename}: not a readable PDF") from e
        pages = []
        for i in range(len(doc)):
            bitmap = doc[i].render(scale=200 / 72)          # 200 DPI, BGR
            arr = np.ascontiguousarray(bitmap.to_numpy())
            pages.append(arr[:, :, :3] if arr.ndim == 3 else cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR))
        return pages
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ScanError(f"{filename}: not a readable image or PDF")
    return [img]


def _find_marks(gray: np.ndarray):
    """Return the 4 corner marks as [(cx, cy, area)] in clockwise order TL,TR,BR,BL (as seen)."""
    h, w = gray.shape
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    corners = [(0, 0), (w, 0), (w, h), (0, h)]
    msg = "Could not find the 4 corner marks. Check the page is fully inside the scan."

    def candidates(bw):
        # RETR_LIST, not RETR_EXTERNAL: a dark paper edge / table shadow can form a closed outline around
        # the whole frame, which would otherwise hide every mark inside it.
        cnts, _ = cv2.findContours(bw, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        out = []
        for c in cnts:
            a = cv2.contourArea(c)
            if not (h * w * 0.0001 < a < h * w * 0.006):
                continue
            x, y, cw, ch = cv2.boundingRect(c)
            # Square-ish and well filled. Small marks in a low-resolution scan measure ~0.84, so the
            # fill limit is loose; filled round bubbles are told apart by how much of their enclosing circle they fill.
            if not 0.75 < cw / ch < 1.33 or a / (cw * ch) < 0.78:
                continue
            (_, _), radius = cv2.minEnclosingCircle(c)
            if a / (np.pi * radius * radius) > 0.8:   # square ≈ 0.64, circle ≈ 1.0
                continue
            out.append((x + cw / 2, y + ch / 2, a))
        return out

    # Global threshold first (flatbed scans); adaptive threshold copes with uneven lighting or a shadowed page.
    block = max(31, (min(h, w) // 8) | 1)
    attempts = (
        lambda: cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1],
        lambda: cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, block, 12),
    )
    for make in attempts:
        cands = candidates(make())
        found = [min(cands, key=lambda c: (c[0] - cx) ** 2 + (c[1] - cy) ** 2, default=None) for cx, cy in corners]
        if None not in found and len({(f[0], f[1]) for f in found}) == 4:
            return found
    raise ScanError(msg)


def align_page(img: np.ndarray, layout: dict) -> np.ndarray:
    """Straighten a scan onto the form's standard page (grayscale, in the layout's pixel coordinates)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    marks = _find_marks(gray)
    k = max(range(4), key=lambda i: marks[i][2])  # the big mark is the top-left of the form
    marks = marks[k:] + marks[:k]
    src = np.float32([[m[0], m[1]] for m in marks])
    dst = np.float32(layout["marks"])
    M = cv2.getPerspectiveTransform(src, dst)
    return cv2.warpPerspective(gray, M, (layout["width"], layout["height"]), flags=cv2.INTER_LINEAR, borderValue=255)


def read_form(img: np.ndarray, layout: dict) -> dict:
    """One-person-per-page form: {field_id: {"selected": [...], "scores": {...}, "flags": [...]}}."""
    return read_single(align_page(img, layout), layout)


def read_single(page: np.ndarray, layout: dict) -> dict:
    return read_fields(page, layout["fields"], float(np.percentile(page, 90)) or 255.0)


def read_rows(page: np.ndarray, layout: dict) -> list[dict]:
    """Multi-row sheet on an aligned page: [{"row": n, "answers": {...}}] for rows that have any mark.
    Rows nobody filled in are skipped."""
    global_paper = float(np.percentile(page, 90)) or 255.0
    out = []
    for rd in layout["rows_data"]:
        answers = read_fields(page, rd["fields"], global_paper)
        used = any(v["selected"] or "multiple" in v["flags"] for v in answers.values())
        written = any(has_writing(page, f["box"], global_paper) for f in rd["fields"] if f["type"] == "write")
        if not used and not written:
            continue
        out.append({"row": rd["row"], "answers": answers})
    return out


def has_writing(page: np.ndarray, box: list, paper: float) -> bool:
    """True if someone wrote in a written-in box (enough dark pixels inside it). The handwriting itself is
    not read; the scan is kept so a person can read it."""
    x0, y0, x1, y1 = box
    cell = page[y0 + 8:y1 - 8, x0 + 8:x1 - 8]          # stay clear of the table lines
    if cell.size == 0:
        return False
    return float((cell < paper * 0.55).mean()) > 0.008


def read_fields(page: np.ndarray, fields: list, global_paper: float) -> dict:
    """Read the shaded circles of the given fields from an aligned page."""
    result = {}
    for f in fields:
        if f["type"] == "write":       # handwriting is not read; nothing to flag
            result[f["id"]] = {"selected": [], "scores": {}, "flags": []}
            continue
        scores = {}
        for o in f["options"]:
            mask = np.zeros(page.shape, np.uint8)
            cv2.circle(mask, (o["cx"], o["cy"]), int(o["r"] * 0.62), 255, -1)
            mean = float(page[mask > 0].mean())
            # Local paper brightness from a ring just outside the circle, so shadows and uneven
            # lighting (a lid not fully closed, a curled page) don't look like shading.
            ring = np.zeros(page.shape, np.uint8)
            cv2.circle(ring, (o["cx"], o["cy"]), int(o["r"] * 1.65), 255, -1)
            cv2.circle(ring, (o["cx"], o["cy"]), int(o["r"] * 1.3), 0, -1)
            paper = float(np.median(page[ring > 0]))
            if paper < 0.4 * global_paper:  # ring fell on something dark; fall back
                paper = global_paper
            scores[o["label"]] = round(max(0.0, 1 - mean / max(paper, 1.0)), 3)
        marked = sorted([l for l, s in scores.items() if s >= MARKED_THRESHOLD], key=lambda l: -scores[l])
        flags = []
        if f["type"] == "single":
            if len(marked) > 1:
                flags.append("multiple")
                marked = marked[:1]
        if not marked:
            flags.append("blank")
        result[f["id"]] = {"selected": marked, "scores": scores, "flags": flags}
    return result
