"""Open FA-Scan in its own app-style window (Microsoft Edge or Chrome in "app mode": no tabs, no address bar).

Shared by the packaged desktop app and the Python launcher. It needs no extra program files, so it works
where Windows security (Smart App Control) refuses unsigned helper DLLs.
"""
import os
import subprocess
from pathlib import Path


def find_browser() -> str | None:
    """Edge first (included with Windows 10/11), then Chrome."""
    rel = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]
    bases = [os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")]
    for r in rel:
        for b in bases:
            if b and (Path(b) / r).exists():
                return str(Path(b) / r)
    try:
        import winreg
        for exe in ("msedge.exe", "chrome.exe"):
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exe}") as k:
                p = winreg.QueryValueEx(k, "")[0]
                if p and Path(p).exists():
                    return p
    except (OSError, ImportError):
        pass
    return None


def open_window(url: str, profile: Path) -> bool:
    """Open the site in its own app-style window. Returns False if no suitable browser was found."""
    exe = find_browser()
    if not exe:
        return False
    profile.mkdir(parents=True, exist_ok=True)
    try:
        # A separate profile keeps this window independent of the person's normal browser.
        subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check",
                          "--disable-background-mode", "--window-size=1366,860"])
        return True
    except OSError:
        return False
