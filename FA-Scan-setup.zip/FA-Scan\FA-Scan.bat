@echo off
rem Double-click to start FA-Scan. It opens in your browser and stops itself when you close the tab.
cd /d "%~dp0backend"
if not exist ".venv\Scripts\pythonw.exe" (
  echo FA-Scan is not set up yet. See README.md ^(first-time setup^).
  pause
  exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" launcher.py
